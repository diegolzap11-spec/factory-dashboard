CREATE TABLE `product_types` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`imageUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `product_types_id` PRIMARY KEY(`id`),
	CONSTRAINT `product_types_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `production` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productTypeId` int NOT NULL,
	`quantity` int NOT NULL,
	`date` timestamp NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`sheetsRowId` varchar(100),
	CONSTRAINT `production_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `raw_material_categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `raw_material_categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `raw_material_categories_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `raw_material_stock` (
	`id` int AUTO_INCREMENT NOT NULL,
	`categoryId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`quantity` decimal(10,2) NOT NULL DEFAULT '0',
	`unit` varchar(20) NOT NULL,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`sheetsRowId` varchar(100),
	CONSTRAINT `raw_material_stock_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sheets_config` (
	`id` int AUTO_INCREMENT NOT NULL,
	`spreadsheetId` varchar(100) NOT NULL,
	`stockSheetName` varchar(100) NOT NULL,
	`productionSheetName` varchar(100) NOT NULL,
	`shipmentsSheetName` varchar(100) NOT NULL,
	`rawMaterialSheetName` varchar(100) NOT NULL,
	`lastSyncTime` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sheets_config_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shipments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productTypeId` int NOT NULL,
	`quantity` int NOT NULL,
	`date` timestamp NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`sheetsRowId` varchar(100),
	CONSTRAINT `shipments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stock` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productTypeId` int NOT NULL,
	`color` varchar(50) NOT NULL,
	`quantity` int NOT NULL DEFAULT 0,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`sheetsRowId` varchar(100),
	CONSTRAINT `stock_id` PRIMARY KEY(`id`)
);
