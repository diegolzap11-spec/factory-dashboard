import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tipos de productos EPP
 */
export const productTypes = mysqlTable("product_types", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(), // casco minero, casco jockey, máscaras, arneses, correas
  description: text("description"),
  imageUrl: text("imageUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProductType = typeof productTypes.$inferSelect;
export type InsertProductType = typeof productTypes.$inferInsert;

/**
 * Stock de productos con colores
 */
export const stock = mysqlTable("stock", {
  id: int("id").autoincrement().primaryKey(),
  productTypeId: int("productTypeId").notNull(),
  color: varchar("color", { length: 50 }).notNull(),
  quantity: int("quantity").notNull().default(0),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
  sheetsRowId: varchar("sheetsRowId", { length: 100 }), // Para sincronizar con Google Sheets
});

export type Stock = typeof stock.$inferSelect;
export type InsertStock = typeof stock.$inferInsert;

/**
 * Registro de producción diaria
 */
export const production = mysqlTable("production", {
  id: int("id").autoincrement().primaryKey(),
  productTypeId: int("productTypeId").notNull(),
  color: varchar("color", { length: 50 }), // Color del producto producido
  quantity: int("quantity").notNull(),
  date: timestamp("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  sheetsRowId: varchar("sheetsRowId", { length: 100 }),
});

export type Production = typeof production.$inferSelect;
export type InsertProduction = typeof production.$inferInsert;

/**
 * Registro de despachos
 */
export const shipments = mysqlTable("shipments", {
  id: int("id").autoincrement().primaryKey(),
  productTypeId: int("productTypeId").notNull(),
  color: varchar("color", { length: 50 }), // Color del producto despachado
  quantity: int("quantity").notNull(),
  date: timestamp("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  sheetsRowId: varchar("sheetsRowId", { length: 100 }),
});

export type Shipment = typeof shipments.$inferSelect;
export type InsertShipment = typeof shipments.$inferInsert;

/**
 * Categorías de insumos (materia prima)
 */
export const rawMaterialCategories = mysqlTable("raw_material_categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(), // materia de alta, materia de baja
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type RawMaterialCategory = typeof rawMaterialCategories.$inferSelect;
export type InsertRawMaterialCategory = typeof rawMaterialCategories.$inferInsert;

/**
 * Stock de insumos (materia prima)
 */
export const rawMaterialStock = mysqlTable("raw_material_stock", {
  id: int("id").autoincrement().primaryKey(),
  categoryId: int("categoryId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull().default("0"),
  unit: varchar("unit", { length: 20 }).notNull(), // kg, metros, unidades, etc.
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
  sheetsRowId: varchar("sheetsRowId", { length: 100 }),
});

export type RawMaterialStock = typeof rawMaterialStock.$inferSelect;
export type InsertRawMaterialStock = typeof rawMaterialStock.$inferInsert;

export const rawMaterialConsumption = mysqlTable("raw_material_consumption", {
  id: int("id").autoincrement().primaryKey(),
  categoryId: int("categoryId").notNull(),
  bagsConsumed: int("bagsConsumed").notNull(),
  quantityConsumed: decimal("quantityConsumed", { precision: 10, scale: 2 }).notNull(),
  date: timestamp("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  sheetsRowId: varchar("sheetsRowId", { length: 100 }),
});

export type RawMaterialConsumption = typeof rawMaterialConsumption.$inferSelect;
export type InsertRawMaterialConsumption = typeof rawMaterialConsumption.$inferInsert;

/**
 * Configuración de sincronización con Google Sheets
 */
export const sheetsConfig = mysqlTable("sheets_config", {
  id: int("id").autoincrement().primaryKey(),
  spreadsheetId: varchar("spreadsheetId", { length: 100 }).notNull(),
  stockSheetName: varchar("stockSheetName", { length: 100 }).notNull(),
  productionSheetName: varchar("productionSheetName", { length: 100 }).notNull(),
  shipmentsSheetName: varchar("shipmentsSheetName", { length: 100 }).notNull(),
  rawMaterialSheetName: varchar("rawMaterialSheetName", { length: 100 }).notNull(),
  lastSyncTime: timestamp("lastSyncTime"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SheetsConfig = typeof sheetsConfig.$inferSelect;
export type InsertSheetsConfig = typeof sheetsConfig.$inferInsert;
