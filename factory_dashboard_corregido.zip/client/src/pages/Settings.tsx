import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Settings as SettingsIcon, RefreshCw, Upload, HelpCircle } from "lucide-react";
import { toast } from "sonner";

const sheetsConfigSchema = z.object({
  spreadsheetId: z.string().min(1, "El ID del Spreadsheet es requerido"),
  stockSheetName: z.string().min(1, "El nombre de la hoja de Stock es requerido"),
  productionSheetName: z.string().min(1, "El nombre de la hoja de Producción es requerido"),
  shipmentsSheetName: z.string().min(1, "El nombre de la hoja de Despachos es requerido"),
  rawMaterialSheetName: z.string().min(1, "El nombre de la hoja de Insumos es requerido"),
});

type SheetsConfigValues = z.infer<typeof sheetsConfigSchema>;

export default function Settings() {
  const [isSyncing, setIsSyncing] = useState(false);

  const { data: config } = trpc.sheets.getConfig.useQuery();
  const updateConfigMutation = trpc.sheets.updateConfig.useMutation();
  const syncAllMutation = trpc.sheets.syncAllFromSheets.useMutation();
  const exportAllMutation = trpc.sheets.exportAllToSheets.useMutation();

  const form = useForm<SheetsConfigValues>({
    resolver: zodResolver(sheetsConfigSchema),
    defaultValues: {
      spreadsheetId: config?.spreadsheetId || "",
      stockSheetName: config?.stockSheetName || "Stock",
      productionSheetName: config?.productionSheetName || "Producción",
      shipmentsSheetName: config?.shipmentsSheetName || "Despachos",
      rawMaterialSheetName: config?.rawMaterialSheetName || "Insumos",
    },
  });

  const onSubmit = async (data: SheetsConfigValues) => {
    try {
      await updateConfigMutation.mutateAsync(data);
      toast.success("Configuración actualizada correctamente");
    } catch (error) {
      toast.error("Error al actualizar la configuración");
    }
  };

  const handleSyncAll = async () => {
    setIsSyncing(true);
    try {
      const result = await syncAllMutation.mutateAsync();
      if (Object.values(result).every((r) => r)) {
        toast.success("Datos sincronizados correctamente desde Google Sheets");
      } else {
        toast.warning("Algunos datos no se sincronizaron correctamente");
      }
    } catch (error) {
      toast.error("Error al sincronizar datos");
    } finally {
      setIsSyncing(false);
    }
  };

  const handleExportAll = async () => {
    setIsSyncing(true);
    try {
      const result = await exportAllMutation.mutateAsync();
      if (Object.values(result).every((r) => r)) {
        toast.success("Datos exportados correctamente a Google Sheets");
      } else {
        toast.warning("Algunos datos no se exportaron correctamente");
      }
    } catch (error) {
      toast.error("Error al exportar datos");
    } finally {
      setIsSyncing(false);
    }
  };

  const formInputClass = "rounded-xl bg-input border-border/50 focus:ring-2 focus:ring-[#E5A820]/30 focus:border-[#E5A820]/50";

  return (
    <DashboardLayout>
      <div className="space-y-8 animate-fade-in">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Configuración</h1>
          <p className="text-sm text-muted-foreground">Gestiona la integración con Google Sheets</p>
        </div>

        {/* Google Sheets Configuration */}
        <Card className="border-border/40 bg-card/80 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-[#E5A820]/10 flex items-center justify-center">
                <SettingsIcon className="h-4 w-4 text-[#E5A820]" />
              </div>
              <div>
                <CardTitle className="text-foreground">Configuración de Google Sheets</CardTitle>
                <p className="text-sm text-muted-foreground mt-0.5">
                  Configura la conexión con tu Google Sheet para sincronizar datos
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="spreadsheetId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground">ID del Spreadsheet</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Ej: 1BxiMVs0XRA5nFMKUVfIvWaWqWVGF7IQkqKGauOE1234"
                          {...field}
                          className={formInputClass}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid gap-4 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="stockSheetName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">Nombre de Hoja: Stock</FormLabel>
                        <FormControl>
                          <Input placeholder="Stock" {...field} className={formInputClass} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="productionSheetName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">Nombre de Hoja: Producción</FormLabel>
                        <FormControl>
                          <Input placeholder="Producción" {...field} className={formInputClass} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="shipmentsSheetName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">Nombre de Hoja: Despachos</FormLabel>
                        <FormControl>
                          <Input placeholder="Despachos" {...field} className={formInputClass} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="rawMaterialSheetName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">Nombre de Hoja: Insumos</FormLabel>
                        <FormControl>
                          <Input placeholder="Insumos" {...field} className={formInputClass} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="submit" className="w-full btn-premium bg-[#E5A820] hover:bg-[#d49a1c] text-black font-semibold rounded-xl">
                  Guardar Configuración
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Sync Actions */}
        <Card className="border-border/40 bg-card/80 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-[#E5A820]/10 flex items-center justify-center">
                <RefreshCw className="h-4 w-4 text-[#E5A820]" />
              </div>
              <div>
                <CardTitle className="text-foreground">Sincronización de Datos</CardTitle>
                <p className="text-sm text-muted-foreground mt-0.5">
                  Sincroniza datos entre el dashboard y Google Sheets
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Button
                  onClick={handleSyncAll}
                  disabled={isSyncing}
                  variant="outline"
                  className="gap-2 rounded-xl border-border/50 hover:bg-secondary/50 hover:border-[#E5A820]/30 text-foreground h-11"
                >
                  <RefreshCw className={`h-4 w-4 ${isSyncing ? "animate-spin" : ""}`} />
                  {isSyncing ? "Sincronizando..." : "Sincronizar desde Google Sheets"}
                </Button>

                <Button
                  onClick={handleExportAll}
                  disabled={isSyncing}
                  variant="outline"
                  className="gap-2 rounded-xl border-border/50 hover:bg-secondary/50 hover:border-[#E5A820]/30 text-foreground h-11"
                >
                  <Upload className={`h-4 w-4 ${isSyncing ? "animate-spin" : ""}`} />
                  {isSyncing ? "Exportando..." : "Exportar a Google Sheets"}
                </Button>
              </div>

              <div className="rounded-xl bg-[#E5A820]/5 border border-[#E5A820]/15 p-4 text-sm text-foreground">
                <p className="font-medium text-[#E5A820] mb-1">Consejo:</p>
                <p className="text-muted-foreground">
                  Usa "Sincronizar desde Google Sheets" para importar datos de tu hoja de cálculo.
                  Usa "Exportar a Google Sheets" para enviar los datos del dashboard a tu hoja.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Help Section */}
        <Card className="border-border/40 bg-card/80 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-[#E5A820]/10 flex items-center justify-center">
                <HelpCircle className="h-4 w-4 text-[#E5A820]" />
              </div>
              <div>
                <CardTitle className="text-foreground">Ayuda</CardTitle>
                <p className="text-sm text-muted-foreground mt-0.5">
                  Instrucciones para configurar Google Sheets
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-5 text-sm">
            <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
              <h4 className="font-medium mb-2 text-foreground">¿Cómo obtener el ID del Spreadsheet?</h4>
              <p className="text-muted-foreground">
                Abre tu Google Sheet y copia el ID de la URL. Por ejemplo, en
                https://docs.google.com/spreadsheets/d/ABC123XYZ/edit, el ID es ABC123XYZ
              </p>
            </div>

            <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
              <h4 className="font-medium mb-2 text-foreground">¿Cómo configurar Google Sheets?</h4>
              <p className="text-muted-foreground">
                Consulta la documentación completa en GOOGLE_SHEETS_SETUP.md para instrucciones
                detalladas sobre cómo crear y configurar tu Google Sheet.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
              <h4 className="font-medium mb-2 text-foreground">Estructura de datos esperada</h4>
              <p className="text-muted-foreground">
                Asegúrate de que tus hojas tengan los encabezados correctos en la primera fila y
                que los datos estén en el formato especificado en la documentación.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
