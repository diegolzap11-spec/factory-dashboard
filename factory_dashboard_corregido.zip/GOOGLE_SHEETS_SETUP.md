# Configuración de Google Sheets para Factory Dashboard

Este documento proporciona instrucciones paso a paso para configurar la integración con Google Sheets en el Factory Dashboard.

## Requisitos Previos

- Una cuenta de Google
- Acceso a Google Cloud Console
- Un Google Sheet creado para almacenar los datos

## Paso 1: Crear un Proyecto en Google Cloud Console

1. Ve a [Google Cloud Console](https://console.cloud.google.com/)
2. Crea un nuevo proyecto o selecciona uno existente
3. Habilita la API de Google Sheets:
   - En el menú de búsqueda, busca "Google Sheets API"
   - Haz clic en "Habilitar"

## Paso 2: Crear una Cuenta de Servicio

1. En Google Cloud Console, ve a "Cuentas de Servicio"
2. Haz clic en "Crear Cuenta de Servicio"
3. Completa los detalles:
   - **Nombre de la cuenta de servicio**: `factory-dashboard-service`
   - **ID de la cuenta de servicio**: Se generará automáticamente
4. Haz clic en "Crear y Continuar"
5. Otorga los permisos necesarios (opcional, puedes saltarlo)
6. Haz clic en "Continuar"

## Paso 3: Crear una Clave JSON

1. En la página de Cuentas de Servicio, selecciona la cuenta que acabas de crear
2. Ve a la pestaña "Claves"
3. Haz clic en "Agregar Clave" → "Crear nueva clave"
4. Selecciona "JSON" como tipo de clave
5. Haz clic en "Crear"
6. Se descargará un archivo JSON automáticamente - **guárdalo en un lugar seguro**

## Paso 4: Crear un Google Sheet

1. Ve a [Google Sheets](https://sheets.google.com/)
2. Crea un nuevo Sheet
3. Renombra las hojas de la siguiente manera:
   - **Stock**: Para datos de inventario
   - **Producción**: Para registros de producción
   - **Despachos**: Para registros de despachos
   - **Insumos**: Para datos de materia prima

## Paso 5: Configurar las Hojas de Google Sheets

### Hoja "Stock"

Crea encabezados en la primera fila:
```
Producto | Color | Cantidad
```

Ejemplo de datos:
```
casco minero | Amarillo | 50
casco minero | Blanco | 30
casco jockey | Azul | 25
máscaras | Blanco | 100
arneses | Negro | 15
correas | Amarillo | 40
```

### Hoja "Producción"

Crea encabezados en la primera fila:
```
Producto | Cantidad | Fecha | Notas
```

Ejemplo de datos:
```
casco minero | 20 | 2026-07-07 | Turno matutino
casco jockey | 15 | 2026-07-07 | Sin incidentes
máscaras | 50 | 2026-07-07 |
```

### Hoja "Despachos"

Crea encabezados en la primera fila:
```
Producto | Cantidad | Fecha | Notas
```

Ejemplo de datos:
```
casco minero | 10 | 2026-07-07 | Destino: Mina A
casco jockey | 5 | 2026-07-07 | Destino: Centro de Equitación
máscaras | 20 | 2026-07-07 |
```

### Hoja "Insumos"

Crea encabezados en la primera fila:
```
Categoría | Nombre | Cantidad | Unidad
```

Ejemplo de datos:
```
materia de alta | Plástico ABS | 500 | kg
materia de alta | Espuma de poliuretano | 200 | metros
materia de baja | Plástico PVC | 300 | kg
materia de baja | Tela de algodón | 100 | metros
```

## Paso 6: Compartir el Sheet con la Cuenta de Servicio

1. Abre tu Google Sheet
2. Haz clic en "Compartir"
3. Copia el email de la cuenta de servicio del archivo JSON descargado (campo `client_email`)
4. Pega el email en el campo de compartir y otorga permisos de "Editor"
5. Haz clic en "Compartir"

## Paso 7: Obtener el ID del Spreadsheet

1. Abre tu Google Sheet
2. En la URL, copia el ID del spreadsheet (la parte entre `/d/` y `/edit`)
3. Ejemplo: `https://docs.google.com/spreadsheets/d/ABC123XYZ/edit` → ID es `ABC123XYZ`

## Paso 8: Configurar en Factory Dashboard

1. Accede al Factory Dashboard como administrador
2. Ve a la sección de configuración (si existe)
3. Ingresa los siguientes datos:
   - **Spreadsheet ID**: El ID que copiaste en el Paso 7
   - **Stock Sheet Name**: `Stock`
   - **Production Sheet Name**: `Producción`
   - **Shipments Sheet Name**: `Despachos`
   - **Raw Material Sheet Name**: `Insumos`

## Paso 9: Sincronizar Datos

Una vez configurado, puedes:

- **Sincronizar desde Google Sheets**: Los datos en Google Sheets se importarán al dashboard
- **Exportar a Google Sheets**: Los datos del dashboard se exportarán a Google Sheets
- **Sincronización automática**: Configura tareas programadas para sincronizar automáticamente

## Troubleshooting

### Error: "Google Sheets no está configurado"

- Verifica que hayas completado todos los pasos de configuración
- Asegúrate de que el Spreadsheet ID sea correcto
- Verifica que la cuenta de servicio tenga acceso al Sheet

### Error: "Permiso denegado"

- Verifica que compartiste el Google Sheet con el email de la cuenta de servicio
- Asegúrate de que otorgaste permisos de "Editor"

### Los datos no se sincronizan

- Verifica que los nombres de las hojas sean exactamente iguales a los configurados
- Asegúrate de que los encabezados estén en la primera fila
- Verifica que los datos estén en el formato correcto

## Estructura de Datos Esperada

### Stock

| Producto | Color | Cantidad |
|----------|-------|----------|
| casco minero | Amarillo | 50 |
| casco jockey | Azul | 25 |

### Producción

| Producto | Cantidad | Fecha | Notas |
|----------|----------|-------|-------|
| casco minero | 20 | 2026-07-07 | Turno matutino |

### Despachos

| Producto | Cantidad | Fecha | Notas |
|----------|----------|-------|-------|
| casco minero | 10 | 2026-07-07 | Destino: Mina A |

### Insumos

| Categoría | Nombre | Cantidad | Unidad |
|-----------|--------|----------|--------|
| materia de alta | Plástico ABS | 500 | kg |
| materia de baja | Tela de algodón | 100 | metros |

## Automatización

Para sincronizar automáticamente los datos, puedes:

1. Usar Google Apps Script para ejecutar sincronizaciones programadas
2. Configurar webhooks en Google Sheets
3. Usar herramientas de automatización como Zapier o Make

## Seguridad

- **Guarda la clave JSON en un lugar seguro**: No la compartas ni la publiques
- **Usa variables de entorno**: Almacena la clave JSON en variables de entorno en lugar de hardcodearla
- **Revisa los permisos regularmente**: Asegúrate de que la cuenta de servicio solo tenga los permisos necesarios
- **Rotación de claves**: Cambia las claves periódicamente por seguridad

## Soporte

Si tienes problemas con la configuración:

1. Verifica que todos los pasos se hayan completado correctamente
2. Revisa los logs del servidor para mensajes de error
3. Consulta la documentación oficial de Google Sheets API
4. Contacta al equipo de soporte del Factory Dashboard
