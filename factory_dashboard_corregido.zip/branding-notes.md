# Flexo Impress - Identidad Visual

## Colores del Logo
- Dorado/Amarillo: #E5A820 (color principal, escudo y "flexo")
- Negro: #1A1A1A (escudo fondo, texto "impress")
- Blanco: #FFFFFF (fondo)

## Paleta Derivada
- Primary: #E5A820 (dorado)
- Primary Dark: #C48E1A
- Primary Light: #F5C84D
- Secondary: #1A1A1A (negro)
- Background: #FFFFFF
- Sidebar: #1A1A1A (negro oscuro)
- Sidebar Text: #FFFFFF
- Sidebar Active: #E5A820
- Card Border: #E5A820 (sutil)
- Accent: #E5A820

## Logo
- Archivo: /home/ubuntu/upload/pasted_file_mFTwHZ_image.png
- Ubicación: Esquina superior izquierda del sidebar
- Texto al lado: "Flexo Impress" + "Sistema de Gestión de Producción e Inventario"

## Reglas
- No cambiar estructura ni funcionalidad
- Mantener verde/amarillo/rojo solo para alertas
- Aplicar en: menú lateral, barra superior, botones, tarjetas, gráficos, iconos
- Estilo: profesional, moderno, industrial
