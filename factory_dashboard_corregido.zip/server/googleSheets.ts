import { google } from "googleapis";
import { JWT } from "google-auth-library";
import * as db from "./db";

/**
 * Módulo de integración con Google Sheets API
 * Permite sincronizar datos entre la base de datos local y Google Sheets
 */

// Inicializar cliente de Google Sheets
let sheetsClient: any = null;

export async function initializeSheetsClient(credentials: any) {
  try {
    const auth = new JWT({
      email: credentials.client_email,
      key: credentials.private_key,
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
    }) as any;

    sheetsClient = google.sheets({ version: "v4", auth });
    console.log("[Google Sheets] Cliente inicializado correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al inicializar cliente:", error);
    return false;
  }
}

/**
 * Leer datos de una hoja de Google Sheets
 */
export async function readSheetData(spreadsheetId: string, range: string) {
  try {
    if (!sheetsClient) {
      console.warn("[Google Sheets] Cliente no inicializado");
      return [];
    }

    const response = await sheetsClient.spreadsheets.values.get({
      spreadsheetId,
      range,
    });

    return response.data.values || [];
  } catch (error) {
    console.error("[Google Sheets] Error al leer datos:", error);
    return [];
  }
}

/**
 * Escribir datos en una hoja de Google Sheets
 */
export async function writeSheetData(
  spreadsheetId: string,
  range: string,
  values: any[][]
) {
  try {
    if (!sheetsClient) {
      console.warn("[Google Sheets] Cliente no inicializado");
      return false;
    }

    await sheetsClient.spreadsheets.values.update({
      spreadsheetId,
      range,
      valueInputOption: "USER_ENTERED",
      requestBody: {
        values,
      },
    });

    console.log("[Google Sheets] Datos escritos correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al escribir datos:", error);
    return false;
  }
}

/**
 * Sincronizar stock desde Google Sheets a la base de datos
 */
export async function syncStockFromSheets(spreadsheetId: string, sheetName: string) {
  try {
    const data = await readSheetData(spreadsheetId, `${sheetName}!A:E`);
    if (data.length === 0) return;

    // Saltar encabezado
    const rows = data.slice(1);

    for (const row of rows) {
      const [productName, color, quantity] = row;
      if (!productName || !color || !quantity) continue;

      // Buscar producto
      const products = await db.getAllProductTypes();
      const product = products.find((p) => p.name.toLowerCase() === productName.toLowerCase());

      if (product) {
        // Buscar o crear entrada de stock
        const existingStock = await db.getStockByProductType(product.id);
        const stockItem = existingStock.find((s) => s.color.toLowerCase() === color.toLowerCase());

        if (stockItem) {
          await db.updateStock(stockItem.id, parseInt(quantity));
        } else {
          await db.createStockEntry(product.id, color, parseInt(quantity));
        }
      }
    }

    console.log("[Google Sheets] Stock sincronizado correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al sincronizar stock:", error);
    return false;
  }
}

/**
 * Sincronizar producción desde Google Sheets a la base de datos
 */
export async function syncProductionFromSheets(spreadsheetId: string, sheetName: string) {
  try {
    const data = await readSheetData(spreadsheetId, `${sheetName}!A:E`);
    if (data.length === 0) return;

    // Saltar encabezado
    const rows = data.slice(1);

    for (const row of rows) {
      const [productName, quantity, date, notes] = row;
      if (!productName || !quantity || !date) continue;

      // Buscar producto
      const products = await db.getAllProductTypes();
      const product = products.find((p) => p.name.toLowerCase() === productName.toLowerCase());

      if (product) {
        // Crear registro de producción
        await db.createProduction(product.id, undefined, parseInt(quantity), new Date(date), notes || "");
      }
    }

    console.log("[Google Sheets] Producción sincronizada correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al sincronizar producción:", error);
    return false;
  }
}

/**
 * Sincronizar despachos desde Google Sheets a la base de datos
 */
export async function syncShipmentsFromSheets(spreadsheetId: string, sheetName: string) {
  try {
    const data = await readSheetData(spreadsheetId, `${sheetName}!A:E`);
    if (data.length === 0) return;

    // Saltar encabezado
    const rows = data.slice(1);

    for (const row of rows) {
      const [productName, quantity, date, notes] = row;
      if (!productName || !quantity || !date) continue;

      // Buscar producto
      const products = await db.getAllProductTypes();
      const product = products.find((p) => p.name.toLowerCase() === productName.toLowerCase());

      if (product) {
        // Crear registro de despacho
        await db.createShipment(product.id, undefined, parseInt(quantity), new Date(date), notes || "");
      }
    }

    console.log("[Google Sheets] Despachos sincronizados correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al sincronizar despachos:", error);
    return false;
  }
}

/**
 * Sincronizar insumos desde Google Sheets a la base de datos
 */
export async function syncRawMaterialsFromSheets(spreadsheetId: string, sheetName: string) {
  try {
    const data = await readSheetData(spreadsheetId, `${sheetName}!A:E`);
    if (data.length === 0) return;

    // Saltar encabezado
    const rows = data.slice(1);

    for (const row of rows) {
      const [categoryName, materialName, quantity, unit] = row;
      if (!categoryName || !materialName || !quantity || !unit) continue;

      // Buscar categoría
      const categories = await db.getAllRawMaterialCategories();
      const category = categories.find((c) => c.name.toLowerCase() === categoryName.toLowerCase());

      if (category) {
        // Crear o actualizar insumo
        const existingMaterials = await db.getRawMaterialByCategory(category.id);
        const material = existingMaterials.find((m) => m.name.toLowerCase() === materialName.toLowerCase());

        if (material) {
          await db.updateRawMaterial(material.id, quantity);
        } else {
          await db.createRawMaterial(category.id, materialName, quantity, unit);
        }
      }
    }

    console.log("[Google Sheets] Insumos sincronizados correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al sincronizar insumos:", error);
    return false;
  }
}

/**
 * Exportar stock a Google Sheets
 */
export async function exportStockToSheets(spreadsheetId: string, sheetName: string) {
  try {
    const allStock = await db.getAllStock();
    const products = await db.getAllProductTypes();

    const rows = allStock.map((stock) => {
      const product = products.find((p) => p.id === stock.productTypeId);
      return [product?.name || "Desconocido", stock.color, stock.quantity];
    });

    // Agregar encabezado
    rows.unshift(["Producto", "Color", "Cantidad"]);

    await writeSheetData(spreadsheetId, `${sheetName}!A:C`, rows);
    console.log("[Google Sheets] Stock exportado correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al exportar stock:", error);
    return false;
  }
}

/**
 * Exportar producción a Google Sheets
 */
export async function exportProductionToSheets(spreadsheetId: string, sheetName: string) {
  try {
    const allProduction = await db.getAllProduction();
    const products = await db.getAllProductTypes();

    const rows = allProduction.map((prod) => {
      const product = products.find((p) => p.id === prod.productTypeId);
      return [
        product?.name || "Desconocido",
        prod.quantity,
        new Date(prod.date).toLocaleDateString("es-ES"),
        prod.notes || "",
      ];
    });

    // Agregar encabezado
    rows.unshift(["Producto", "Cantidad", "Fecha", "Notas"]);

    await writeSheetData(spreadsheetId, `${sheetName}!A:D`, rows);
    console.log("[Google Sheets] Producción exportada correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al exportar producción:", error);
    return false;
  }
}

/**
 * Exportar despachos a Google Sheets
 */
export async function exportShipmentsToSheets(spreadsheetId: string, sheetName: string) {
  try {
    const allShipments = await db.getAllShipments();
    const products = await db.getAllProductTypes();

    const rows = allShipments.map((shipment) => {
      const product = products.find((p) => p.id === shipment.productTypeId);
      return [
        product?.name || "Desconocido",
        shipment.quantity,
        new Date(shipment.date).toLocaleDateString("es-ES"),
        shipment.notes || "",
      ];
    });

    // Agregar encabezado
    rows.unshift(["Producto", "Cantidad", "Fecha", "Notas"]);

    await writeSheetData(spreadsheetId, `${sheetName}!A:D`, rows);
    console.log("[Google Sheets] Despachos exportados correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al exportar despachos:", error);
    return false;
  }
}

/**
 * Exportar insumos a Google Sheets
 */
export async function exportRawMaterialsToSheets(spreadsheetId: string, sheetName: string) {
  try {
    const allMaterials = await db.getAllRawMaterial();
    const categories = await db.getAllRawMaterialCategories();

    const rows = allMaterials.map((material) => {
      const category = categories.find((c) => c.id === material.categoryId);
      return [category?.name || "Desconocido", material.name, material.quantity, material.unit];
    });

    // Agregar encabezado
    rows.unshift(["Categoría", "Nombre", "Cantidad", "Unidad"]);

    await writeSheetData(spreadsheetId, `${sheetName}!A:D`, rows);
    console.log("[Google Sheets] Insumos exportados correctamente");
    return true;
  } catch (error) {
    console.error("[Google Sheets] Error al exportar insumos:", error);
    return false;
  }
}
