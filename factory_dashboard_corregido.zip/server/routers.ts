import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { sheetsRouter } from "./sheetsRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  sheets: sheetsRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ==================== PRODUCTS ====================
  products: router({
    list: publicProcedure.query(async () => {
      return db.getAllProductTypes();
    }),
    
    getById: publicProcedure.input(z.number()).query(async ({ input }) => {
      return db.getProductTypeById(input);
    }),

    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        imageUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return db.createProductType(input.name, input.description, input.imageUrl);
      }),
  }),

  // ==================== STOCK ====================
  stock: router({
    getAll: publicProcedure.query(async () => {
      return db.getAllStock();
    }),

    getByProductType: publicProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return db.getStockByProductType(input);
      }),

    update: protectedProcedure
      .input(z.object({
        stockId: z.number(),
        quantity: z.number(),
      }))
      .mutation(async ({ input }) => {
        return db.updateStock(input.stockId, input.quantity);
      }),

    create: protectedProcedure
      .input(z.object({
        productTypeId: z.number(),
        color: z.string(),
        quantity: z.number(),
      }))
      .mutation(async ({ input }) => {
        return db.createStockEntry(input.productTypeId, input.color, input.quantity);
      }),
  }),

  // ==================== PRODUCTION ====================
  production: router({
    getAll: publicProcedure.query(async () => {
      return db.getAllProduction();
    }),

    getByDate: publicProcedure
      .input(z.date())
      .query(async ({ input }) => {
        return db.getProductionByDate(input);
      }),

    create: protectedProcedure
      .input(z.object({
        productTypeId: z.number(),
        color: z.string().optional(),
        quantity: z.number(),
        date: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return db.createProduction(input.productTypeId, input.color, input.quantity, input.date, input.notes);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        productTypeId: z.number(),
        color: z.string().optional(),
        quantity: z.number(),
        date: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return db.updateProduction(input.id, input.productTypeId, input.color, input.quantity, input.date, input.notes);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteProduction(input.id);
      }),
  }),

  // ==================== SHIPMENTS ====================
  shipments: router({
    getAll: publicProcedure.query(async () => {
      return db.getAllShipments();
    }),

    getByDate: publicProcedure
      .input(z.date())
      .query(async ({ input }) => {
        return db.getShipmentsByDate(input);
      }),

    create: protectedProcedure
      .input(z.object({
        productTypeId: z.number(),
        color: z.string().optional(),
        quantity: z.number(),
        date: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        // createShipment ya maneja el descuento de stock automáticamente
        return db.createShipment(input.productTypeId, input.color, input.quantity, input.date, input.notes);
      }),
  }),

  // ==================== RAW MATERIALS ====================
  rawMaterials: router({
    getCategories: publicProcedure.query(async () => {
      return db.getAllRawMaterialCategories();
    }),

    getAll: publicProcedure.query(async () => {
      return db.getAllRawMaterial();
    }),

    create: protectedProcedure
      .input(z.object({
        categoryId: z.number(),
        name: z.string(),
        quantity: z.string(),
        unit: z.string(),
      }))
      .mutation(async ({ input }) => {
        return db.createRawMaterial(input.categoryId, input.name, input.quantity, input.unit);
      }),

    update: protectedProcedure
      .input(z.object({
        materialId: z.number(),
        quantity: z.string(),
      }))
      .mutation(async ({ input }) => {
        return db.updateRawMaterial(input.materialId, input.quantity);
      }),
  }),

  consumption: router({
    getAll: publicProcedure.query(async () => {
      return db.getAllRawMaterialConsumption();
    }),

    getByDate: publicProcedure
      .input(z.date())
      .query(async ({ input }) => {
        return db.getConsumptionByDate(input);
      }),

    create: protectedProcedure
      .input(z.object({
        categoryId: z.number(),
        bagsConsumed: z.number().min(1, "Debe consumir al menos 1 bolsa"),
        date: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return db.createConsumption(input.categoryId, input.bagsConsumed, input.date, input.notes);
      }),
  }),
});

export type AppRouter = typeof appRouter;
