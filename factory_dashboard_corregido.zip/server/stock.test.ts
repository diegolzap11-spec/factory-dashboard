import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock db module
vi.mock("./db", () => {
  let stockData: { id: number; productTypeId: number; color: string; quantity: number }[] = [];
  let productionData: { id: number; productTypeId: number; color?: string; quantity: number; date: Date; notes?: string }[] = [];
  let nextStockId = 1;
  let nextProductionId = 1;

  return {
    getAllProductTypes: vi.fn(() => [
      { id: 1, name: "Casco Jockey I", description: null, imageUrl: null, createdAt: new Date() },
      { id: 2, name: "Casco Minero", description: null, imageUrl: null, createdAt: new Date() },
      { id: 3, name: "Mascarillas Tipo AS", description: null, imageUrl: null, createdAt: new Date() },
    ]),
    getProductTypeById: vi.fn((id: number) => {
      const products = [
        { id: 1, name: "Casco Jockey I" },
        { id: 2, name: "Casco Minero" },
        { id: 3, name: "Mascarillas Tipo AS" },
      ];
      return products.find(p => p.id === id) || null;
    }),
    getAllStock: vi.fn(() => stockData),
    getStockByProductType: vi.fn((productTypeId: number) => stockData.filter(s => s.productTypeId === productTypeId)),
    getStockByProductTypeAndColor: vi.fn((productTypeId: number, color: string) => {
      return stockData.find(s => s.productTypeId === productTypeId && s.color === color) || null;
    }),
    updateStock: vi.fn((stockId: number, quantity: number) => {
      const item = stockData.find(s => s.id === stockId);
      if (item) item.quantity = quantity;
    }),
    createStockEntry: vi.fn((productTypeId: number, color: string, quantity: number) => {
      const entry = { id: nextStockId++, productTypeId, color, quantity };
      stockData.push(entry);
      return entry;
    }),
    getAllProduction: vi.fn(() => productionData),
    getProductionByDate: vi.fn(() => []),
    createProduction: vi.fn(async (productTypeId: number, color: string | undefined, quantity: number, date: Date, notes?: string) => {
      const record = { id: nextProductionId++, productTypeId, color, quantity, date, notes };
      productionData.push(record);
      
      // Simulate stock increase
      if (color) {
        const existing = stockData.find(s => s.productTypeId === productTypeId && s.color === color);
        if (existing) {
          existing.quantity += quantity;
        } else {
          stockData.push({ id: nextStockId++, productTypeId, color, quantity });
        }
      }
      return record;
    }),
    updateProduction: vi.fn(async (productionId: number, productTypeId: number, color: string | undefined, quantity: number, date: Date, notes?: string) => {
      const old = productionData.find(p => p.id === productionId);
      if (!old) return null;
      
      // Revert old stock
      if (old.color) {
        const existingStock = stockData.find(s => s.productTypeId === old.productTypeId && s.color === old.color);
        if (existingStock) {
          existingStock.quantity = Math.max(0, existingStock.quantity - old.quantity);
        }
      }
      
      // Apply new stock
      if (color) {
        const existingStock = stockData.find(s => s.productTypeId === productTypeId && s.color === color);
        if (existingStock) {
          existingStock.quantity += quantity;
        } else {
          stockData.push({ id: nextStockId++, productTypeId, color, quantity });
        }
      }
      
      // Update record
      old.productTypeId = productTypeId;
      old.color = color;
      old.quantity = quantity;
      old.date = date;
      old.notes = notes;
      
      return old;
    }),
    deleteProduction: vi.fn(async (productionId: number) => {
      const prod = productionData.find(p => p.id === productionId);
      if (!prod) return null;
      
      // Revert stock
      if (prod.color) {
        const existingStock = stockData.find(s => s.productTypeId === prod.productTypeId && s.color === prod.color);
        if (existingStock) {
          existingStock.quantity = Math.max(0, existingStock.quantity - prod.quantity);
        }
      }
      
      productionData = productionData.filter(p => p.id !== productionId);
      return true;
    }),
    getAllShipments: vi.fn(() => []),
    getShipmentsByDate: vi.fn(() => []),
    createShipment: vi.fn(async (productTypeId: number, color: string | undefined, quantity: number, date: Date, notes?: string) => {
      // Simulate stock decrease
      if (color) {
        const existingStock = stockData.find(s => s.productTypeId === productTypeId && s.color === color);
        if (existingStock) {
          if (existingStock.quantity < quantity) {
            throw new Error(`Stock insuficiente. Disponible: ${existingStock.quantity}, Solicitado: ${quantity}`);
          }
          existingStock.quantity -= quantity;
        } else {
          throw new Error(`No existe stock para este producto y color`);
        }
      }
      return { id: 1, productTypeId, color, quantity, date, notes };
    }),
    getAllRawMaterialCategories: vi.fn(() => []),
    getAllRawMaterial: vi.fn(() => []),
    getAllRawMaterialConsumption: vi.fn(() => []),
    getConsumptionByDate: vi.fn(() => []),
    createConsumption: vi.fn(() => null),
    createRawMaterial: vi.fn(() => null),
    updateRawMaterial: vi.fn(() => null),
    createProductType: vi.fn(() => null),
    getSheetsConfig: vi.fn(() => null),
    updateSheetsConfig: vi.fn(() => null),
    updateSheetsLastSync: vi.fn(() => null),
    // Reset function for tests
    _reset: () => {
      stockData = [];
      productionData = [];
      nextStockId = 1;
      nextProductionId = 1;
    },
  };
});

function createTestContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Stock Integration", () => {
  let db: any;

  beforeEach(async () => {
    db = await import("./db");
    db._reset();
  });

  it("production increases stock for specific product and color", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // Register production: 500 Casco Jockey Amarillo
    await caller.production.create({
      productTypeId: 1,
      color: "Amarillo",
      quantity: 500,
      date: new Date(),
    });

    expect(db.createProduction).toHaveBeenCalledWith(1, "Amarillo", 500, expect.any(Date), undefined);
  });

  it("production accumulates stock (does not replace)", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // First production: 100 units
    await caller.production.create({
      productTypeId: 1,
      color: "Amarillo",
      quantity: 100,
      date: new Date(),
    });

    // Second production: 50 units
    await caller.production.create({
      productTypeId: 1,
      color: "Amarillo",
      quantity: 50,
      date: new Date(),
    });

    // Stock should be 150 (accumulated)
    const allStock = await caller.stock.getAll();
    const jockeyAmarillo = allStock.find((s: any) => s.productTypeId === 1 && s.color === "Amarillo");
    expect(jockeyAmarillo?.quantity).toBe(150);
  });

  it("shipment decreases stock for specific product and color", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // First produce 200 units
    await caller.production.create({
      productTypeId: 1,
      color: "Amarillo",
      quantity: 200,
      date: new Date(),
    });

    // Then ship 50 units
    await caller.shipments.create({
      productTypeId: 1,
      color: "Amarillo",
      quantity: 50,
      date: new Date(),
    });

    // Stock should be 150
    const allStock = await caller.stock.getAll();
    const jockeyAmarillo = allStock.find((s: any) => s.productTypeId === 1 && s.color === "Amarillo");
    expect(jockeyAmarillo?.quantity).toBe(150);
  });

  it("shipment throws error when stock is insufficient", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // Produce 100 units
    await caller.production.create({
      productTypeId: 1,
      color: "Amarillo",
      quantity: 100,
      date: new Date(),
    });

    // Try to ship 200 units (more than available)
    await expect(
      caller.shipments.create({
        productTypeId: 1,
        color: "Amarillo",
        quantity: 200,
        date: new Date(),
      })
    ).rejects.toThrow("Stock insuficiente");
  });

  it("deleting production reverts stock", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // Produce 500 units
    await caller.production.create({
      productTypeId: 1,
      color: "Blanco",
      quantity: 500,
      date: new Date(),
    });

    // Stock should be 500
    let allStock = await caller.stock.getAll();
    let item = allStock.find((s: any) => s.productTypeId === 1 && s.color === "Blanco");
    expect(item?.quantity).toBe(500);

    // Delete the production record (id = 1)
    await caller.production.delete({ id: 1 });

    // Stock should be 0
    allStock = await caller.stock.getAll();
    item = allStock.find((s: any) => s.productTypeId === 1 && s.color === "Blanco");
    expect(item?.quantity).toBe(0);
  });

  it("editing production recalculates stock correctly", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // Produce 500 units
    await caller.production.create({
      productTypeId: 2,
      color: "Rojo",
      quantity: 500,
      date: new Date(),
    });

    // Stock should be 500
    let allStock = await caller.stock.getAll();
    let item = allStock.find((s: any) => s.productTypeId === 2 && s.color === "Rojo");
    expect(item?.quantity).toBe(500);

    // Edit to 300 units
    await caller.production.update({
      id: 1,
      productTypeId: 2,
      color: "Rojo",
      quantity: 300,
      date: new Date(),
    });

    // Stock should be 300 (reverted 500, added 300)
    allStock = await caller.stock.getAll();
    item = allStock.find((s: any) => s.productTypeId === 2 && s.color === "Rojo");
    expect(item?.quantity).toBe(300);
  });
});
