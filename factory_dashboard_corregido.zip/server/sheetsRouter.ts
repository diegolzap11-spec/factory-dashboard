import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import * as sheets from "./googleSheets";

export const sheetsRouter = router({
  /**
   * Obtener configuración actual de Google Sheets
   */
  getConfig: protectedProcedure.query(async () => {
    return db.getSheetsConfig();
  }),

  /**
   * Actualizar configuración de Google Sheets
   */
  updateConfig: protectedProcedure
    .input(
      z.object({
        spreadsheetId: z.string(),
        stockSheetName: z.string(),
        productionSheetName: z.string(),
        shipmentsSheetName: z.string(),
        rawMaterialSheetName: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return db.updateSheetsConfig(
        input.spreadsheetId,
        input.stockSheetName,
        input.productionSheetName,
        input.shipmentsSheetName,
        input.rawMaterialSheetName
      );
    }),

  /**
   * Sincronizar stock desde Google Sheets
   */
  syncStockFromSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const success = await sheets.syncStockFromSheets(
      config.spreadsheetId,
      config.stockSheetName
    );

    if (success) {
      await db.updateSheetsLastSync();
    }

    return { success };
  }),

  /**
   * Sincronizar producción desde Google Sheets
   */
  syncProductionFromSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const success = await sheets.syncProductionFromSheets(
      config.spreadsheetId,
      config.productionSheetName
    );

    if (success) {
      await db.updateSheetsLastSync();
    }

    return { success };
  }),

  /**
   * Sincronizar despachos desde Google Sheets
   */
  syncShipmentsFromSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const success = await sheets.syncShipmentsFromSheets(
      config.spreadsheetId,
      config.shipmentsSheetName
    );

    if (success) {
      await db.updateSheetsLastSync();
    }

    return { success };
  }),

  /**
   * Sincronizar insumos desde Google Sheets
   */
  syncRawMaterialsFromSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const success = await sheets.syncRawMaterialsFromSheets(
      config.spreadsheetId,
      config.rawMaterialSheetName
    );

    if (success) {
      await db.updateSheetsLastSync();
    }

    return { success };
  }),

  /**
   * Exportar stock a Google Sheets
   */
  exportStockToSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const success = await sheets.exportStockToSheets(
      config.spreadsheetId,
      config.stockSheetName
    );

    return { success };
  }),

  /**
   * Exportar producción a Google Sheets
   */
  exportProductionToSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const success = await sheets.exportProductionToSheets(
      config.spreadsheetId,
      config.productionSheetName
    );

    return { success };
  }),

  /**
   * Exportar despachos a Google Sheets
   */
  exportShipmentsToSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const success = await sheets.exportShipmentsToSheets(
      config.spreadsheetId,
      config.shipmentsSheetName
    );

    return { success };
  }),

  /**
   * Exportar insumos a Google Sheets
   */
  exportRawMaterialsToSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const success = await sheets.exportRawMaterialsToSheets(
      config.spreadsheetId,
      config.rawMaterialSheetName
    );

    return { success };
  }),

  /**
   * Sincronizar todos los datos desde Google Sheets
   */
  syncAllFromSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const results = {
      stock: await sheets.syncStockFromSheets(config.spreadsheetId, config.stockSheetName),
      production: await sheets.syncProductionFromSheets(config.spreadsheetId, config.productionSheetName),
      shipments: await sheets.syncShipmentsFromSheets(config.spreadsheetId, config.shipmentsSheetName),
      rawMaterials: await sheets.syncRawMaterialsFromSheets(config.spreadsheetId, config.rawMaterialSheetName),
    };

    if (Object.values(results).every((r) => r)) {
      await db.updateSheetsLastSync();
    }

    return results;
  }),

  /**
   * Exportar todos los datos a Google Sheets
   */
  exportAllToSheets: protectedProcedure.mutation(async () => {
    const config = await db.getSheetsConfig();
    if (!config) {
      throw new Error("Google Sheets no está configurado");
    }

    const results = {
      stock: await sheets.exportStockToSheets(config.spreadsheetId, config.stockSheetName),
      production: await sheets.exportProductionToSheets(config.spreadsheetId, config.productionSheetName),
      shipments: await sheets.exportShipmentsToSheets(config.spreadsheetId, config.shipmentsSheetName),
      rawMaterials: await sheets.exportRawMaterialsToSheets(config.spreadsheetId, config.rawMaterialSheetName),
    };

    return results;
  }),
});
