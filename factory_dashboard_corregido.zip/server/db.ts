import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, productTypes, stock, production, shipments, rawMaterialCategories, rawMaterialStock, rawMaterialConsumption, sheetsConfig } from "../drizzle/schema";
import { ENV } from './_core/env';
import { eq, desc, and, gte, lte } from "drizzle-orm";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ==================== PRODUCT TYPES ====================

export async function getAllProductTypes() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(productTypes);
}

export async function getProductTypeById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(productTypes).where(eq(productTypes.id, id)).limit(1);
  return result[0] || null;
}

export async function createProductType(name: string, description?: string, imageUrl?: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(productTypes).values({ name, description, imageUrl });
  return result;
}

// ==================== STOCK ====================

export async function getStockByProductType(productTypeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stock).where(eq(stock.productTypeId, productTypeId));
}

export async function getStockByProductTypeAndColor(productTypeId: number, color: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(stock).where(
    and(
      eq(stock.productTypeId, productTypeId),
      eq(stock.color, color)
    )
  );
  return result.length > 0 ? result[0] : null;
}

export async function getAllStock() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stock);
}

export async function updateStock(stockId: number, quantity: number) {
  const db = await getDb();
  if (!db) return null;
  return db.update(stock).set({ quantity }).where(eq(stock.id, stockId));
}

export async function createStockEntry(productTypeId: number, color: string, quantity: number) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(stock).values({ productTypeId, color, quantity });
}

// ==================== PRODUCTION ====================

export async function getProductionByDate(date: Date) {
  const db = await getDb();
  if (!db) return [];
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  
  return db.select().from(production).where(
    and(
      gte(production.date, startOfDay),
      lte(production.date, endOfDay)
    )
  );
}

export async function getAllProduction() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(production).orderBy(desc(production.date));
}

export async function createProduction(productTypeId: number, color: string | undefined, quantity: number, date: Date, notes?: string) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(production).values({ productTypeId, color, quantity, date, notes });
  
  // Aumentar stock automáticamente
  if (color) {
    const existingStock = await getStockByProductTypeAndColor(productTypeId, color);
    if (existingStock) {
      const newQuantity = existingStock.quantity + quantity;
      await updateStock(existingStock.id, newQuantity);
    } else {
      await createStockEntry(productTypeId, color, quantity);
    }
  }
  
  return result;
}

export async function updateProduction(productionId: number, productTypeId: number, color: string | undefined, quantity: number, date: Date, notes?: string) {
  const db = await getDb();
  if (!db) return null;
  
  // Obtener la producción anterior
  const oldProduction = await db.select().from(production).where(eq(production.id, productionId)).limit(1);
  if (!oldProduction || oldProduction.length === 0) return null;
  
  const old = oldProduction[0];
  
  // Revertir el stock anterior
  if (old.color) {
    const existingStock = await getStockByProductTypeAndColor(old.productTypeId, old.color);
    if (existingStock) {
      const newQuantity = Math.max(0, existingStock.quantity - old.quantity);
      await updateStock(existingStock.id, newQuantity);
    }
  }
  
  // Aplicar el nuevo stock
  if (color) {
    const existingStock = await getStockByProductTypeAndColor(productTypeId, color);
    if (existingStock) {
      const newQuantity = existingStock.quantity + quantity;
      await updateStock(existingStock.id, newQuantity);
    } else {
      await createStockEntry(productTypeId, color, quantity);
    }
  }
  
  // Actualizar el registro de producción
  return db.update(production).set({ productTypeId, color, quantity, date, notes }).where(eq(production.id, productionId));
}

export async function deleteProduction(productionId: number) {
  const db = await getDb();
  if (!db) return null;
  
  // Obtener la producción a eliminar
  const productionRecord = await db.select().from(production).where(eq(production.id, productionId)).limit(1);
  if (!productionRecord || productionRecord.length === 0) return null;
  
  const prod = productionRecord[0];
  
  // Revertir el stock
  if (prod.color) {
    const existingStock = await getStockByProductTypeAndColor(prod.productTypeId, prod.color);
    if (existingStock) {
      const newQuantity = Math.max(0, existingStock.quantity - prod.quantity);
      await updateStock(existingStock.id, newQuantity);
    }
  }
  
  // Eliminar el registro de producción
  return db.delete(production).where(eq(production.id, productionId));
}

// ==================== SHIPMENTS ====================

export async function getShipmentsByDate(date: Date) {
  const db = await getDb();
  if (!db) return [];
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  
  return db.select().from(shipments).where(
    and(
      gte(shipments.date, startOfDay),
      lte(shipments.date, endOfDay)
    )
  );
}

export async function getAllShipments() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(shipments).orderBy(desc(shipments.date));
}

export async function createShipment(productTypeId: number, color: string | undefined, quantity: number, date: Date, notes?: string) {
  const db = await getDb();
  if (!db) return null;
  
  // Descontar stock automáticamente
  if (color) {
    const existingStock = await getStockByProductTypeAndColor(productTypeId, color);
    if (existingStock) {
      if (existingStock.quantity < quantity) {
        throw new Error(`Stock insuficiente. Disponible: ${existingStock.quantity}, Solicitado: ${quantity}`);
      }
      const newQuantity = existingStock.quantity - quantity;
      await updateStock(existingStock.id, newQuantity);
    } else {
      throw new Error(`No existe stock para este producto y color`);
    }
  }
  
  return db.insert(shipments).values({ productTypeId, color, quantity, date, notes });
}

// ==================== RAW MATERIALS ====================

export async function getAllRawMaterialCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(rawMaterialCategories);
}

export async function getRawMaterialByCategory(categoryId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(rawMaterialStock).where(eq(rawMaterialStock.categoryId, categoryId));
}

export async function getAllRawMaterial() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(rawMaterialStock);
}

export async function updateRawMaterial(materialId: number, quantity: string) {
  const db = await getDb();
  if (!db) return null;
  return db.update(rawMaterialStock).set({ quantity }).where(eq(rawMaterialStock.id, materialId));
}

export async function createRawMaterial(categoryId: number, name: string, quantity: string, unit: string) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(rawMaterialStock).values({ categoryId, name, quantity, unit });
}

// ==================== RAW MATERIAL CONSUMPTION ====================

export async function getAllRawMaterialConsumption() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(rawMaterialConsumption).orderBy(desc(rawMaterialConsumption.date));
}

export async function getConsumptionByDate(date: Date) {
  const db = await getDb();
  if (!db) return [];
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  
  return db.select().from(rawMaterialConsumption).where(
    and(
      gte(rawMaterialConsumption.date, startOfDay),
      lte(rawMaterialConsumption.date, endOfDay)
    )
  );
}

export async function createConsumption(categoryId: number, bagsConsumed: number, date: Date, notes?: string) {
  const db = await getDb();
  if (!db) return null;
  const quantityConsumed = (bagsConsumed * 25).toString();
  
  const consumption = await db.insert(rawMaterialConsumption).values({ categoryId, bagsConsumed, quantityConsumed: quantityConsumed as any, date, notes });
  
  const materials = await getRawMaterialByCategory(categoryId);
  if (materials && materials.length > 0) {
    for (const material of materials) {
      const currentQty = parseFloat(material.quantity.toString());
      const newQty = Math.max(0, currentQty - (bagsConsumed * 25));
      await updateRawMaterial(material.id, newQty.toString());
    }
  }
  
  return consumption;
}

// ==================== SHEETS CONFIG ====================

export async function getSheetsConfig() {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(sheetsConfig).limit(1);
  return result[0] || null;
}

export async function updateSheetsConfig(spreadsheetId: string, stockSheetName: string, productionSheetName: string, shipmentsSheetName: string, rawMaterialSheetName: string) {
  const db = await getDb();
  if (!db) return null;
  
  const existing = await getSheetsConfig();
  if (existing) {
    return db.update(sheetsConfig).set({
      spreadsheetId,
      stockSheetName,
      productionSheetName,
      shipmentsSheetName,
      rawMaterialSheetName,
    }).where(eq(sheetsConfig.id, existing.id));
  } else {
    return db.insert(sheetsConfig).values({
      spreadsheetId,
      stockSheetName,
      productionSheetName,
      shipmentsSheetName,
      rawMaterialSheetName,
    });
  }
}

export async function updateSheetsLastSync() {
  const db = await getDb();
  if (!db) return null;
  
  const existing = await getSheetsConfig();
  if (existing) {
    return db.update(sheetsConfig).set({
      lastSyncTime: new Date(),
    }).where(eq(sheetsConfig.id, existing.id));
  }
}
